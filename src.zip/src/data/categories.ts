// Beginner-friendly na paliwanag sa bawat category.
// Sadyang walang "sections", "tips" o "level": ikaw ang magdedesisyon kung ano
// ang ilalagay at paano ito idi-disenyo.
//
// Ang `name` ay lumalabas sa reel at sa brief, kaya huwag baguhin ang spelling
// kung may naka-save nang briefs ang user.

export type CategoryInfo = {
  name: string;
  /** Ano ba talaga ito, sa simpleng salita */
  what: string;
  /** Mga totoong klase ng website na pwede mong isipin */
  think: string;
};

export const categoryInfo: readonly CategoryInfo[] = [
  {
    name: "Architecture",
    what: "Website ng architect o building studio. Ipinapakita ang mga proyekto nilang gusali o bahay.",
    think:
      "Portfolio ng architecture firm, o page para sa isang bagong building.",
  },
  {
    name: "Art & Illustration",
    what: "Website ng artist o illustrator para ipakita ang gawa nila.",
    think: "Online gallery, portfolio ng illustrator, shop ng prints.",
  },
  {
    name: "Business & Corporate",
    what: "Website ng normal na kumpanya na may serbisyo o produktong binebenta sa ibang negosyo.",
    think: "Accounting firm, logistics company, consulting group.",
  },
  {
    name: "Culture & Education",
    what: "Website ng museo, aklatan, paaralan, o online course.",
    think: "Museum website, university page, language learning site.",
  },
  {
    name: "Design Agencies",
    what: "Website ng agency na gumagawa ng design o website para sa ibang kumpanya. Ito ang 'portfolio ng mga portfolio'.",
    think: "Creative studio na may case studies, awards, at client list.",
  },
  {
    name: "E-Commerce",
    what: "Online store. May produkto, cart, at checkout.",
    think: "Tindahan ng sapatos, kape, o gadgets.",
  },
  {
    name: "Events",
    what: "Website para sa isang event: conference, festival, concert, o kasal.",
    think: "Tech conference page, music festival, wedding invitation site.",
  },
  {
    name: "Experimental",
    what: "Walang rules. Ang website mismo ang ipinagmamalaki, hindi ang laman nito. Mas parang sining kaysa produkto.",
    think:
      "Site na gumagalaw ayon sa mouse mo, 3D na mundo, kakaibang scroll, laro.",
  },
  {
    name: "Fashion",
    what: "Website ng clothing brand o designer.",
    think: "Clothing label, lookbook, runway collection.",
  },
  {
    name: "Film & TV",
    what: "Website para sa pelikula, serye, o production company.",
    think: "Movie landing page na may trailer, o page ng isang TV show.",
  },
  {
    name: "Food & Drink",
    what: "Website ng pagkain o inumin na produkto o brand, hindi ng restaurant mismo.",
    think: "Brand ng sauce, kapehan na nagbebenta ng beans, craft beer.",
  },
  {
    name: "Games & Entertainment",
    what: "Website ng laro, game studio, o entertainment brand.",
    think: "Landing page ng indie game, esports team, streaming channel.",
  },
  {
    name: "Hotel / Restaurant",
    what: "Website ng lugar na pupuntahan ng tao: hotel, resort, o kainan.",
    think: "Boutique hotel, ramen shop, beach resort.",
  },
  {
    name: "Institutions",
    what: "Website ng organisasyon na hindi kumikita, o ng gobyerno o ahensya. Nagbibigay ng serbisyo o impormasyon sa publiko.",
    think: "City hall, hospital, bangko, unibersidad, embahada.",
  },
  {
    name: "Luxury",
    what: "Website ng mamahaling brand. Ang pakiramdam ay eksklusibo at pino.",
    think: "Relo, alahas, designer perfume, mamahaling kotse.",
  },
  {
    name: "Magazine / Newspaper / Blog",
    what: "Website na puro artikulo at binabasa. Content ang bida.",
    think: "Online news site, personal blog, magazine.",
  },
  {
    name: "Music & Sound",
    what: "Website ng musikero, banda, label, o podcast.",
    think: "Artist page na may album at tour dates, podcast site.",
  },
  {
    name: "Photography",
    what: "Portfolio ng photographer.",
    think: "Wedding photographer, travel photographer, photo series.",
  },
  {
    name: "Promotional",
    what: "One-page site para sa isang kampanya, produkto, o promo na may limitadong panahon.",
    think: "Landing page ng bagong phone, sale campaign, app launch.",
  },
  {
    name: "Real Estate",
    what: "Website para sa pagbebenta o pagpapaupa ng bahay, condo, o lupa.",
    think: "Condo developer page, property listing site.",
  },
  {
    name: "Social Responsibility",
    what: "Website ng adbokasiya, charity, o kilusan na tumutulong sa komunidad o kalikasan.",
    think: "Tree-planting group, animal shelter, donation campaign.",
  },
  {
    name: "Sports",
    what: "Website ng koponan, liga, atleta, o sports brand.",
    think: "Basketball team page, gym, running event, sports apparel.",
  },
  {
    name: "Startups",
    what: "Website ng bagong kumpanya na may bagong produkto, karaniwan app o software.",
    think: "SaaS landing page, fintech app, AI tool.",
  },
  {
    name: "Technology",
    what: "Website ng tech product, hardware, o developer tool. Mas teknikal kaysa Startups.",
    think: "Docs site ng library, gadget page, cloud service.",
  },
  {
    name: "Web & Interactive",
    what: "Website na ang halaga ay nasa interaksyon: tools, visualization, kwentong ginagalawan, o mini app.",
    think:
      "Data visualization, interactive story, online calculator, configurator.",
  },
];

/** Listahan ng pangalan lang, para sa reel. */
export const categories: readonly string[] = categoryInfo.map((c) => c.name);

export const infoFor = (name: string) =>
  categoryInfo.find((c) => c.name === name);
