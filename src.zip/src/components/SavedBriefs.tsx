import { useState } from "react";
import { briefSentence } from "../lib/brief";
import { downloadText } from "../lib/download";
import { exportJSON, exportMarkdown, type SavedBrief } from "../lib/saved";
import { computeStats } from "../lib/stats";

type Filter = "all" | "todo" | "done";

const FILTERS: { id: Filter; label: string }[] = [
  { id: "all", label: "All" },
  { id: "todo", label: "To build" },
  { id: "done", label: "Built" },
];

type SavedBriefsProps = {
  saved: readonly SavedBrief[];
  onToggle: (id: string) => void;
  onRemove: (id: string) => void;
};

export default function SavedBriefs({
  saved,
  onToggle,
  onRemove,
}: SavedBriefsProps) {
  const [filter, setFilter] = useState<Filter>("all");

  const stats = computeStats(saved);
  const visible = saved.filter(
    (x) => filter === "all" || (filter === "done" ? x.done : !x.done),
  );

  return (
    <section className="saved">
      <p className="result-label">
        Saved briefs: {stats.built} built / {stats.total}
      </p>

      {(stats.streak > 0 || stats.topCategory) && (
        <p className="stats">
          {stats.streak > 0 &&
            `Streak: ${stats.streak} ${stats.streak === 1 ? "day" : "days"}`}
          {stats.streak > 0 && stats.topCategory && " / "}
          {stats.topCategory && `Most built: ${stats.topCategory}`}
        </p>
      )}

      <div className="saved-tools">
        <div className="group" role="group" aria-label="Filter saved briefs">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              type="button"
              className="lock chip"
              aria-pressed={filter === f.id}
              onClick={() => setFilter(f.id)}
            >
              {f.label}
            </button>
          ))}
        </div>

        <div className="group">
          <button
            type="button"
            className="lock chip"
            onClick={() =>
              downloadText("briefs.md", exportMarkdown(saved), "text/markdown")
            }
          >
            Export .md
          </button>
          <button
            type="button"
            className="lock chip"
            onClick={() =>
              downloadText("briefs.json", exportJSON(saved), "application/json")
            }
          >
            Export .json
          </button>
        </div>
      </div>

      {visible.length === 0 ? (
        <p className="empty">Nothing here yet.</p>
      ) : (
        <ul>
          {visible.map((x) => (
            <li key={x.id} className={x.done ? "is-done" : ""}>
              <label>
                <input
                  type="checkbox"
                  checked={x.done}
                  onChange={() => onToggle(x.id)}
                />
                <span>{briefSentence(x)}</span>
              </label>
              <button
                type="button"
                className="remove"
                onClick={() => onRemove(x.id)}
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
