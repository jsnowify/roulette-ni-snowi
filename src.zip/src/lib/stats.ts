import type { SavedBrief } from "./saved";

const dayKey = (t: number) => {
  const d = new Date(t);
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
};

/** Ilang magkakasunod na araw (hanggang ngayon o kahapon) na may natapos kang brief. */
function streak(done: readonly SavedBrief[]): number {
  const days = new Set<string>();
  for (const x of done) if (x.doneAt !== null) days.add(dayKey(x.doneAt));

  const cursor = new Date();
  cursor.setHours(0, 0, 0, 0);
  // Kung wala pang natapos ngayong araw, hindi pa nawawala ang streak: simula sa kahapon.
  if (!days.has(dayKey(cursor.getTime()))) cursor.setDate(cursor.getDate() - 1);

  let count = 0;
  while (days.has(dayKey(cursor.getTime()))) {
    count += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return count;
}

export function computeStats(list: readonly SavedBrief[]) {
  const done = list.filter((x) => x.done);

  const perCategory = new Map<string, number>();
  for (const x of done) {
    perCategory.set(x.category, (perCategory.get(x.category) ?? 0) + 1);
  }

  let topCategory: string | null = null;
  let best = 0;
  for (const [category, n] of perCategory) {
    if (n > best) {
      best = n;
      topCategory = category;
    }
  }

  return {
    built: done.length,
    total: list.length,
    topCategory,
    streak: streak(done),
  };
}
